﻿namespace MyLibrary;

public class Calculator
{

    public static double Add(double a, double b)
    {
        return a + b;
    }

    public double Subtract(double a, double b)
    {
        return a - b;
    }
}